<div id="cookie-selector">
    <input type="radio" name="box-type" id="radio-box-type-pres" value="1"> Buy a preselected package <br/>
    <input type="radio" name="box-type" id="radio-box-type-sel" value="2"> Select the cookies you want <br/>

    <div id="cookie-selector-block" style="display: none;">
        <div class="cookie-selector-info">
            You have <span id="cookie-selector-num-left">0</span> cookies left.
        </div>
        <div class="cookie-wrapper">
            <?php

            $query = new EntityFieldQuery();

            $query->entityCondition('entity_type', 'node');
            $query->entityCondition('bundle', 'cookie_type');
            $result = $query->execute();

            if (isset($result['node'])) {
                $items_nids = array_keys($result['node']);
                $items = entity_load('node', $items_nids);
            }

            foreach ($items as $c) {
                ?>
                <div class="cookie-item">

                    <img src="<?php echo file_create_url($c->field_image_main['und'][0]['uri']); ?>"
                         style="width:50px;height:50px;">
                    <br/>
                    <a href="#" class="cookie-remove-btn" num="<?php echo $c->vid; ?>">-</a>
                    <span class="small-title-cookie">&nbsp; <?php echo $c->title ?> &nbsp;</span>
                    <a href="#" class="cookie-add-btn" num="<?php echo $c->vid; ?>">+</a>
                    <br/>

                    <p class="cookie-counter" num="<?php echo $c->vid; ?>">0</p>
                </div>
            <?php } ?>

            <div class="clearfix"></div>
        </div>
    </div>
    <input type="hidden" id="cookie-input" name="line_item_fields[field_cookie_selector][und][0][value]"/>

</div>

<?php
$nid = arg(1);
$node = node_load($nid);
$node_wrapper = entity_metadata_wrapper('node', $node);
$id = $node_wrapper->field_product->value();
$product = commerce_product_load($id[0]->product_id);
$product_wrapper = entity_metadata_wrapper('commerce_product', $product);
$display = $product_wrapper->field_number_of_cookies->value();
?>
<script type="text/javascript">
    jQuery(document).ready(function ($) {

        $('.commerce-add-to-cart').find('#edit-submit').addClass('disabled-bnt');
        $('.disabled-bnt').attr('style', 'background-color: darkgray; cursor: default; pointer-events: none;');

        var cookieMax = <?php echo $display; ?>;

        function GetAllCookies() {
            var sum = 0;
            $('.cookie-counter').each(function () {
                sum += parseInt($(this).text());
            });
            return sum;
        }

        function UpdateNumLeft() {
            $('#cookie-selector-num-left').html((cookieMax - GetAllCookies()));
        }

        UpdateNumLeft();

        function UpdateInput() {
            var obj = [];

            $(".cookie-counter").each(function () {
                obj.push({ vid: $(this).attr('num'), count: parseInt($(this).text()) });
            });

            $('#cookie-input').val(JSON.stringify(obj));
        }


        //adding a cookie
        $(".cookie-add-btn").click(function (event) {
            event.preventDefault();
            if (GetAllCookies() < cookieMax) {
                var num = $(this).attr("num");
                var count = parseInt($('.cookie-counter[num="' + num + '"]').text());
                $('.cookie-counter[num="' + num + '"]').text(count + 1);
                UpdateNumLeft();
                UpdateInput();
            }
            if ((GetAllCookies() - cookieMax) == 0) {
                $('.commerce-add-to-cart').find('#edit-submit').removeClass('disabled-bnt');
                $('.commerce-add-to-cart').find('#edit-submit').removeAttr('style');
            }
        });

        //removing a cookie
        $(".cookie-remove-btn").click(function () {
            event.preventDefault();
            var num = $(this).attr("num");
            var count = parseInt($('.cookie-counter[num="' + num + '"]').text());
            if (count > 0) {
                $('.cookie-counter[num="' + num + '"]').text(count - 1);
                UpdateNumLeft();
                UpdateInput();
            }
        });

        $("#radio-box-type-sel").click(function () {
            $("#cookie-selector-block").show();
        });
        $("#radio-box-type-pres").click(function () {
            $("#cookie-selector-block").hide();
        });


    });

</script>